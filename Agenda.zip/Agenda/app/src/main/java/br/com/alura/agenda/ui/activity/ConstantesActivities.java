package br.com.alura.agenda.ui.activity;

interface ConstantesActivities {
    String CHAVE_ALUNO = "aluno";
}
